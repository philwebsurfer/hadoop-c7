#!/bin/bash
service ssh start
cat /etc/hosts.cluster > /etc/hosts
if [ -f '/tmp/hadoop-root/dfs/data/current/VERSION' ]
then
	echo HDFS is formatted, skipping formatting
else 
	echo HDFS is formatted, formatting...
	$HADOOP_PREFIX/bin/hdfs namenode -format
fi
cp -a /usr/local/hadoop/etc/hadoop/core-site.xml.cluster /usr/local/hadoop/etc/hadoop/core-site.xml
cp -a /usr/local/hadoop/etc/hadoop/yarn-site.xml.cluster /usr/local/hadoop/etc/hadoop/yarn-site.xml
$HADOOP_PREFIX/sbin/start-dfs.sh
$HADOOP_PREFIX/sbin/start-yarn.sh
/bin/bash

