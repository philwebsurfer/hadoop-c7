service ssh start
start-dfs.sh
start-yarn.sh
/bin/bash

