#!/bin/bash
service ssh start
$HADOOP_PREFIX/sbin/start-dfs.sh
$HADOOP_PREFIX/sbin/start-yarn.sh
$HADOOP_PREFIX/mr-jobhistory-daemon.sh start historyserver
/bin/bash

